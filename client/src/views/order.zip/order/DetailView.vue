<template>
    <div>
DetailView
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>