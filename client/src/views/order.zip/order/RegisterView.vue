<template>
    <div>
        RegisterView
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>